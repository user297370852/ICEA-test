## Product Requirement Document

# DOM Querying & Assertion Toolkit — Locate and Verify Elements in a Rendered Fragment

## Project Goal

Build a small toolkit that lets developers locate elements inside a rendered HTML fragment using human-meaningful, accessibility-oriented criteria, and verify properties of those elements (visibility, classes, inline styles) as well as plain object shapes, so that UI assertions read the way a person would describe them instead of relying on brittle structural selectors.

---

## Background & Problem

When verifying rendered output, developers often reach for low-level structural selectors (deep CSS paths, nth-child chains) that break the moment the markup is rearranged, and they hand-roll repetitive checks for whether an element is visible, whether it has the right classes, or whether its style matches. This produces fragile, verbose verification code that says little about intent.

This toolkit provides two cohesive capabilities. First, a set of locators that find elements the way a user perceives them — by visible text, by an associated label, by placeholder, by image alternative text, by a title, by a control's display value, or by an element's full normalized text content. Second, a set of assertions that answer precise yes/no questions about a located element — is it visible or hidden, does it carry an expected ordered (or unordered) class list, do its inline styles include expected values — plus a structural assertion that checks whether one object is a partial of another. Inputs are plain data (an HTML fragment plus the query/criteria); outputs are stable, line-oriented text describing exactly what was found or whether the check passed.

---

## Architecture & Engineering Constraints

To ensure this project is delivered as a maintainable software artifact, the following architectural and non-functional requirements (NFRs) MUST be strictly observed:

1. **Scale-Driven Code Organization:** The physical structure of the codebase MUST perfectly match the complexity of the domain.
   - **For micro-utilities/simple scripts:** A well-organized, single-file solution is perfectly acceptable, provided it maintains clean logical separation.
   - **For complex systems:** If the project involves multiple distinct responsibilities (e.g., I/O routing, business rules, formatters), it MUST NOT be a single "god file". You must output a clear, multi-file directory tree (`src/`, `tests/`, etc.) that reflects a production-grade repository.
   Do not over-engineer simple problems, but strictly avoid monolithic files for complex domains.

2. **Strict Separation of Concerns (Anti-Overfitting):**
   The JSON input/output test cases provided in the "Core Features" section represent a **black-box testing contract** for the execution adapter, NOT the internal data model of the core system. The core business logic must remain completely decoupled from standard I/O (stdin/stdout) and JSON parsing. The execution adapter is solely responsible for translating JSON commands into idiomatic method calls to the core domain.

3. **Adherence to SOLID Design Principles:**
   The architectural design must follow SOLID principles to ensure maintainability and scalability (scaled appropriately to the project's size):
   - **Single Responsibility Principle (SRP):** Separate parsing, routing, validation, core execution, and output formatting into distinct logical units.
   - **Open/Closed Principle (OCP):** The core engine must be open for extension but closed for modification.
   - **Liskov Substitution Principle (LSP):** Derived types must be perfectly substitutable for their base types.
   - **Interface Segregation Principle (ISP):** Keep interfaces/protocols small and highly cohesive.
   - **Dependency Inversion Principle (DIP):** High-level modules should depend on abstractions, not low-level I/O implementation details.

4. **Robustness & Interface Design:**
   - **Idiomatic Usage:** The public interface of the core system must be elegant and idiomatic to the target programming language, hiding internal complexity.
   - **Resilience:** The system must handle edge cases gracefully. Errors should be modeled properly (e.g., specific Exception types or Result/Monad patterns) rather than relying on generic faults.

---

## Core Features

### Feature 1: Accessibility-Oriented Element Locators

**As a developer**, I want to find elements by the way they are perceived (visible text, label, placeholder, alternative text, title, display value), so I can write resilient queries that survive markup refactors.

**Expected Behavior / Usage:**

The input supplies an HTML fragment, a query strategy, and a target string. Supported strategies are: visible text of an element, the text of a label associated with a form control (the control is returned, not the label), a control's placeholder, an image's alternative text, an element's title, and a control's current display value. Matching is exact against the relevant accessible text. The locator returns every matching element in document order. The output reports a `count=<n>` line followed by one `match=<tag>#<id>` line per matched element (lowercased tag name; the literal `(no-id)` is used when the element has no id). When a strategy can match several elements, all are listed in order. An optional CSS selector may be supplied to restrict the candidates to elements matching that selector, which is useful to disambiguate when the same text appears more than once.

**Test Cases:** `rcb_tests/public_test_cases/feature1_accessible_queries.json`

```json
{
    "description": "Locate elements inside an HTML fragment using accessibility-oriented queries. Each request names the query strategy: visible text content, an associated form label, a placeholder, image alternative text, a title attribute, or a control's current display value. The query returns every matching element in document order; the report lists how many were found and, for each, its tag name and id. An optional CSS selector narrows the candidate set so only elements matching that selector are considered.",
    "cases": [
        {
            "input": {"op": "locate", "by": "text", "match": "By text", "html": "<p id=\"by-text-p\">By text</p><p id=\"by-text-p-2\">By text</p>"},
            "expected_output": "count=2\nmatch=p#by-text-p\nmatch=p#by-text-p-2\n"
        },
        {
            "input": {"op": "locate", "by": "label", "match": "By label", "html": "<label for=\"by-label-input\">By label</label><input type=\"text\" id=\"by-label-input\" />"},
            "expected_output": "count=1\nmatch=input#by-label-input\n"
        }
    ]
}
```

---

### Feature 2: Locate By Normalized Text Content

**As a developer**, I want to find an element by the full text it renders (including the text of its descendants), with configurable normalization, so I can match against what the user actually reads even when the text is split across child elements.

**Expected Behavior / Usage:**

The input supplies an HTML fragment, a mandatory CSS selector restricting which elements are tested, and a target. The element's text content is the concatenation of all descendant text, passed through a normalizer before comparison. By default the normalizer trims leading/trailing whitespace and collapses every run of whitespace to a single space, and the comparison is exact and case-sensitive. Two flags adjust normalization independently: disabling trimming makes leading/trailing whitespace significant, and disabling whitespace collapsing makes repeated internal spaces significant. A flag can switch matching from exact to case-insensitive substring containment. Alternatively the target may be a regular expression (given as a pattern with optional flags) tested against the normalized text. The output reports a `count=<n>` line followed by one `match=<tag>#<id>` line per matched element; `count=0` with no further lines means nothing matched.

**Test Cases:** `rcb_tests/public_test_cases/feature2_text_content_query.json`

```json
{
    "description": "Locate an element whose collected text content (the concatenation of all descendant text) matches a target, after a normalization step. By default the normalizer trims the ends and collapses runs of whitespace to single spaces, and matching is exact and case-sensitive. A mandatory selector restricts which elements are tested. Matching can be made substring-based instead of exact, and the two normalization steps (trimming, whitespace collapsing) can each be turned off so leading/trailing or repeated spaces become significant. The target may also be given as a regular expression tested against the normalized text. The report lists how many elements matched and each match's tag name and id.",
    "cases": [
        {
            "input": {"op": "locate-content", "matcher": "some deeply NESTED TEXT", "selector": "#text-content-root", "html": "<div id=\"text-content-root\"><span> some </span><span><span id=\"text-content-span-1\"><span>deeply</span><span> </span><span> </span>NESTED</span><span id=\"text-content-span-2\"> TEXT </span></span></div>"},
            "expected_output": "count=1\nmatch=div#text-content-root\n"
        },
        {
            "input": {"op": "locate-content", "matcher": "deeply nested", "exact": false, "selector": "#text-content-root", "html": "<div id=\"text-content-root\"><span> some </span><span><span id=\"text-content-span-1\"><span>deeply</span><span> </span><span> </span>NESTED</span><span id=\"text-content-span-2\"> TEXT </span></span></div>"},
            "expected_output": "count=1\nmatch=div#text-content-root\n"
        }
    ]
}
```

---

### Feature 3: Visibility Assertion

**As a developer**, I want to ask whether an element is visible or hidden, so I can assert on rendering state without inspecting individual style rules myself.

**Expected Behavior / Usage:**

The input supplies an HTML fragment and a CSS selector addressing the element. An element is considered hidden when it, or any of its ancestors, is removed from rendering by any of the following: a `display:none` style, a `visibility:hidden` style, a `hidden` attribute, or (for form controls) an input whose type is `hidden`. Otherwise it is visible. The two outcomes are complementary. The output echoes the queried `selector`, then a `visible=<bool>` line and a `hidden=<bool>` line.

**Test Cases:** `rcb_tests/public_test_cases/feature3_visibility.json`

```json
{
    "description": "Determine whether a referenced element is visible or hidden. An element counts as hidden when it (or any ancestor) is removed from rendering via a display:none style, a visibility:hidden style, a hidden attribute, or, for form controls, an input whose type is hidden; otherwise it is visible. The element is addressed by a CSS selector against the supplied HTML fragment. The report echoes the selector and the two complementary outcomes.",
    "cases": [
        {
            "input": {"op": "visibility", "selector": "#visible", "html": "<div id=\"visible\">Visible</div>"},
            "expected_output": "selector=#visible\nvisible=true\nhidden=false\n"
        },
        {
            "input": {"op": "visibility", "selector": "#display-none", "html": "<div id=\"display-none\" style=\"display:none\">Hidden with display none</div>"},
            "expected_output": "selector=#display-none\nvisible=false\nhidden=true\n"
        }
    ]
}
```

---

### Feature 4: Class List Assertion (Ordered or Unordered)

**As a developer**, I want to assert that an element carries an expected set of classes, optionally enforcing their order, so I can verify styling state precisely.

**Expected Behavior / Usage:**

The input supplies an HTML fragment, a CSS selector, and a list of expected class names. By default the check is order-sensitive: the element must carry exactly the requested classes in the requested order. A non-strict flag relaxes this so the element only needs to contain all requested classes in any order. The output reports a `pass=<bool>` line and an `actual=<class list>` line echoing the element's current class attribute (empty when it has none).

**Test Cases:** `rcb_tests/public_test_cases/feature4_class_assertion.json`

```json
{
    "description": "Check whether an element carries an expected set of CSS classes. By default the check is order-sensitive: the element must carry exactly the requested classes in the requested order. A non-strict mode relaxes this so the element only has to contain all requested classes in any order. The element is addressed by a CSS selector against the supplied HTML fragment. The report states whether the check passed and echoes the element's actual class list.",
    "cases": [
        {
            "input": {"op": "class", "selector": "#classes", "classes": ["class-a", "class-b"], "html": "<div id=\"classes\" class=\"class-a class-b\">Classes</div>"},
            "expected_output": "pass=true\nactual=class-a class-b\n"
        },
        {
            "input": {"op": "class", "selector": "#classes", "classes": ["class-b", "class-a"], "html": "<div id=\"classes\" class=\"class-a class-b\">Classes</div>"},
            "expected_output": "pass=false\nactual=class-a class-b\n"
        }
    ]
}
```

---

### Feature 5: Inline Style Assertion

**As a developer**, I want to assert that an element's inline styles include expected property/value pairs, so I can verify applied styling without comparing whole style strings.

**Expected Behavior / Usage:**

The input supplies an HTML fragment, a CSS selector, and a map of expected CSS property names to expected values. The check passes only when every requested property is present on the element's inline style and its value matches the expected value, with surrounding whitespace ignored in the comparison; a property that is absent, or present with a different value, fails the check. The output reports a `pass=<bool>` line, then one `<property>=<actual value>` line per requested property echoing the element's actual inline value (empty when the property is not set).

**Test Cases:** `rcb_tests/public_test_cases/feature5_style_assertion.json`

```json
{
    "description": "Check whether an element's inline styles include every expected CSS property/value pair. The check passes only when each requested property is present on the element and its value matches the expected value (whitespace is ignored in the comparison); a missing property or a differing value fails the check. The element is addressed by a CSS selector against the supplied HTML fragment. The report states whether the check passed and echoes the element's actual value for each requested property (empty when the property is not set).",
    "cases": [
        {
            "input": {"op": "style", "selector": "#styles", "styles": {"background-color": "indianred"}, "html": "<div id=\"styles\" style=\"background-color: indianred; color: chocolate;\"></div>"},
            "expected_output": "pass=true\nbackground-color=indianred\n"
        },
        {
            "input": {"op": "style", "selector": "#styles", "styles": {"height": "100px"}, "html": "<div id=\"styles\" style=\"background-color: indianred; color: chocolate;\"></div>"},
            "expected_output": "pass=false\nheight=\n"
        }
    ]
}
```

---

### Feature 6: Partial Object Assertion

**As a developer**, I want to assert that one object is a partial of another, so I can verify that a value contains an expected subset of properties without listing every property.

**Expected Behavior / Usage:**

The input supplies an `actual` object and an `expected` object. The check passes when every property present in `expected` also exists on `actual` with a strictly equal value (so an identical object also passes); it fails when any expected property is missing from `actual` or holds a different value. The output reports a `pass=<bool>` line, then one `<key>=match` or `<key>=mismatch` line per property in `expected`, in declaration order.

**Test Cases:** `rcb_tests/public_test_cases/feature6_partial_object.json`

```json
{
    "description": "Check whether one object is a partial of another: every property present in the expected object must exist on the actual object with a strictly equal value. The check passes when the expected object is a subset of the actual object (including when they are identical) and fails when any expected property is missing or has a different value. The report states whether the check passed and, for each expected property, whether it matched the actual object.",
    "cases": [
        {
            "input": {"op": "partial", "actual": {"lorem": "first", "ipsum": "second"}, "expected": {"lorem": "first"}},
            "expected_output": "pass=true\nlorem=match\n"
        },
        {
            "input": {"op": "partial", "actual": {"lorem": "first", "ipsum": "second"}, "expected": {"lorem": "second"}},
            "expected_output": "pass=false\nlorem=mismatch\n"
        }
    ]
}
```

---

## Deliverables

1. **The Core System:** A cleanly structured codebase implementing the locators and assertions described above. Its physical structure (single-file vs. multi-file repository) MUST strictly align with the "Scale-Driven Code Organization" constraint, ensuring high maintainability without over-engineering. The core logic operates over live DOM elements and plain objects and must be decoupled from standard I/O (stdin/stdout) and JSON parsing.

2. **The Execution/Test Adapter:** A runnable program (CLI script or entry point) that acts as a client to your core system — logically (and ideally physically) separated from the core domain. It reads a single JSON request from stdin, mounts the supplied HTML fragment into a DOM, invokes the appropriate core logic, and prints the resulting report to stdout, matching the per-feature contracts above. The request's `op` selects behavior: `locate` and `locate-content` run a locator and list the matches as `count=<n>` plus `match=<tag>#<id>` lines; `visibility`, `class`, `style`, and `partial` run an assertion and report `pass`/outcome lines as specified per feature. Any internal native error must be rendered as a single neutral `error=<category>` line rather than leaking host runtime details.

3. **Automated test harness**. The cases embedded in this PRD live under `rcb_tests/public_test_cases/`. A single entry point `bash rcb_tests/test.sh` reads every `*.json` case file from a case directory and runs the full suite; it accepts `--cases-dir <subdir>` to point at a directory of case files (default `test_cases`). For each case it writes one file to `rcb_tests/stdout/<cases-dir>/{filename.stem}@{case_index.zfill(3)}.txt`. Output is namespaced by `<cases-dir>` so running different case directories never overwrites each other. Each `.txt` file contains **only** the raw stdout from the program under test (no PASS/FAIL summaries or metadata) so it can be compared directly against `expected_output`.


---
**Implementation notes:**
- follow the same ancestor checking logic as the tree walker utility for shadow roots
