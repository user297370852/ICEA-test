## Product Requirement Document

# Technical-Analysis Indicator Engine — Moving Averages & Momentum Over a Price Series

## Project Goal

Build a reusable numeric engine that computes classic technical-analysis indicators (moving averages and a momentum oscillator) over a fixed series of closing prices, so analysts and trading tools can turn a raw price history into smoothed trend lines and momentum readings without re-deriving the formulas or worrying about rounding inconsistencies.

---

## Background & Problem

A price history is just an ordered list of closing prices, one per period. To reason about trend and momentum, analysts repeatedly need derived series: a simple moving average that smooths noise, an exponential moving average that reacts faster to recent moves, a weighted moving average that emphasises the latest prices, and a relative-strength reading that quantifies recent up-vs-down pressure.

Without a shared engine, every tool re-implements these recurrences slightly differently — disagreeing on how to treat the leading edge of the series (before a full look-back window exists), on smoothing constants, and on rounding. The result is subtly different numbers from tool to tool. This engine fixes one precise contract for each indicator: given a series and a window length, it returns the full indicator curve (one value per position, in order) as fixed-precision decimals, with well-defined behaviour at the start of the series and at degenerate inputs.

All indicator values in this contract are rendered as decimal strings rounded half-up to exactly four fractional digits (for example `3.3333`, `100.0000`, `64.7500`). A value that is mathematically undefined is rendered as the literal text `[a special string literal for undefined values]`.

---

## Architecture & Engineering Constraints

To ensure this project is delivered as a maintainable software artifact, the following architectural and non-functional requirements (NFRs) MUST be strictly observed:

1. **Scale-Driven Code Organization:** The physical structure of the codebase MUST perfectly match the complexity of the domain.
   - **For micro-utilities/simple scripts:** A well-organized, single-file solution is perfectly acceptable, provided it maintains clean logical separation.
   - **For complex systems:** If the project involves multiple distinct responsibilities (e.g., I/O routing, business rules, formatters), it MUST NOT be a single "god file". You must output a clear, multi-file directory tree (`src/`, `tests/`, etc.) that reflects a production-grade repository.
   Do not over-engineer simple problems, but strictly avoid monolithic files for complex domains.

2. **Strict Separation of Concerns (Anti-Overfitting):**
   The JSON input/output test cases provided in the "Core Features" section represent a **black-box testing contract** for the execution adapter, NOT the internal data model of the core system. The core business logic must remain completely decoupled from standard I/O (stdin/stdout) and JSON parsing. The execution adapter is solely responsible for translating JSON commands into idiomatic method calls to the core domain.

3. **Adherence to SOLID Design Principles:**
   The architectural design must follow SOLID principles to ensure maintainability and scalability (scaled appropriately to the project's size):
   - **Single Responsibility Principle (SRP):** Separate parsing, routing, validation, core execution, and output formatting into distinct logical units.
   - **Open/Closed Principle (OCP):** The core engine must be open for extension but closed for modification — adding a new indicator should not require rewriting existing ones.
   - **Liskov Substitution Principle (LSP):** Derived types must be perfectly substitutable for their base types.
   - **Interface Segregation Principle (ISP):** Keep interfaces/protocols small and highly cohesive.
   - **Dependency Inversion Principle (DIP):** High-level modules should depend on abstractions, not low-level I/O implementation details.

4. **Robustness & Interface Design:**
   - **Idiomatic Usage:** The public interface of the core system must be elegant and idiomatic to the target programming language, hiding internal complexity. Indicators should compose: an indicator reads from a source (the close prices, or another indicator) and exposes a value at each position.
   - **Resilience:** The system must handle edge cases gracefully (windows longer than the series, leading positions before a full window, division by zero). Undefined results should be modeled explicitly (e.g., a dedicated not-a-number value) rather than crashing.

---

## Core Features

Every feature consumes the same request shape: a JSON object with an `indicator` name (a string), a `timeFrame` (the positive integer window length), and a `series` (an ordered array of closing prices as numbers). The response is the full indicator curve — exactly one rendered value per series position, in input order, each on its own line, terminated by a newline. Values are decimals rounded half-up to four fractional digits. If the `indicator` name is not recognised, the adapter emits a neutral error: a line `error=unknown_indicator` followed by a line `indicator=<name>`.

### Feature 1: Simple Moving Average

**As a developer**, I want each position replaced by the average of the most recent window of closing prices, so I can smooth out short-term noise and see the underlying trend.

**Expected Behavior / Usage:**

For each position `i`, the value is the arithmetic mean of the closing prices in the window ending at `i` and spanning at most `timeFrame` prices. Near the start of the series, before `timeFrame` prices are available, the mean is taken over only the prices seen so far (positions `0..i`), i.e. a shorter window of length `i+1`. Once a full window exists, it is the mean of the most recent `timeFrame` prices. A `timeFrame` of `1` therefore reproduces the input series exactly. Each value is rendered rounded half-up to four fractional digits.

**Test Cases:** `rcb_tests/public_test_cases/feature1_sma_moving_average.json`

```json
{
    "description": "Compute the simple moving average of a close-price series for a given window length. The output is the indicator curve: one value per input position, in order, each rounded half-up to four decimal places. For positions before a full window of data exists, the average is taken over only the data available so far (a shorter window); once enough data is present, it is the arithmetic mean of the most recent window-length values. A window length of one reproduces the input series.",
    "cases": [
        {
            "input": {"indicator": "sma", "timeFrame": 3, "series": [1, 2, 3, 4, 3, 4, 5, 4, 3, 3, 4, 3, 2]},
            "expected_output": "1.0000\n1.5000\n2.0000\n3.0000\n3.3333\n3.6667\n4.0000\n4.3333\n4.0000\n3.3333\n3.3333\n3.3333\n3.0000"
        }
    ]
}
```

---

### Feature 2: Exponential Moving Average

**As a developer**, I want a moving average that weights recent prices more heavily and reacts faster than the simple average, so I can track momentum shifts sooner.

**Expected Behavior / Usage:**

The smoothing weight is `2 / (timeFrame + 1)`. Before a full window of data exists (positions whose one-based count is below `timeFrame`), each value equals the simple moving average over that same growing window, which seeds the recurrence; in particular the value at position `0` equals the first closing price. Once a full window is available, each value is computed recursively as `previousValue + weight * (currentPrice - previousValue)`. A `timeFrame` of `1` makes the weight `1`, so the output reproduces the input series exactly. Each value is rendered rounded half-up to four fractional digits.

**Test Cases:** `rcb_tests/public_test_cases/feature2_ema_moving_average.json`

```json
{
    "description": "Compute the exponential moving average of a close-price series for a given window length. The output is the indicator curve: one value per position, in order, each rounded half-up to four decimal places. Before a full window of data is available, each value equals the simple moving average over the same growing window; once the window is full, each value blends the current price with the previous exponential average using the smoothing weight two divided by (window length plus one). A window length of one reproduces the input series.",
    "cases": [
        {
            "input": {"indicator": "ema", "timeFrame": 10, "series": [64.75, 63.79, 63.73, 63.73, 63.55, 63.19, 63.91, 63.85, 62.95, 63.37, 61.33, 61.51]},
            "expected_output": "64.7500\n64.2700\n64.0900\n64.0000\n63.9100\n63.7900\n63.8071\n63.8125\n63.7167\n63.6536\n63.2312\n62.9182"
        }
    ]
}
```

---

### Feature 3: Weighted Moving Average

**As a developer**, I want a moving average in which the most recent price carries the largest weight and weights decline linearly toward the oldest price in the window, so I can emphasise the latest data while still smoothing.

**Expected Behavior / Usage:**

Within a full window of length `k = timeFrame`, the most recent price is multiplied by `k`, the next by `k-1`, and so on down to `1` for the oldest, and the sum is divided by `k(k+1)/2` (the sum of the weights). Near the start of the series, before a full window exists — including the case where `timeFrame` is larger than the whole series — the same linear weighting is applied over only the prices available so far: at position `i` the weights run from `i+1` (most recent) down to `1`, divided by `(i+1)(i+2)/2`. The value at position `0` is the first closing price. Each value is rendered rounded half-up to four fractional digits.

**Test Cases:** `rcb_tests/public_test_cases/feature3_wma_moving_average.json`

```json
{
    "description": "Compute the linearly weighted moving average of a close-price series for a given window length, where within each window the most recent price carries the largest integer weight and the oldest the smallest (weights 1..k summing to k(k+1)/2). The output is the indicator curve: one value per position, in order, each rounded half-up to four decimal places. For positions before a full window exists (including when the window length exceeds the series size), the weighting is applied over only the data available so far.",
    "cases": [
        {
            "input": {"indicator": "wma", "timeFrame": 3, "series": [1, 2, 3, 4, 5, 6]},
            "expected_output": "1.0000\n1.6667\n2.3333\n3.3333\n4.3333\n5.3333"
        }
    ]
}
```

---

### Feature 4: Relative Strength Index

**As a developer**, I want a bounded momentum reading (0–100) that compares the size of recent gains to recent losses, so I can judge whether a series is being pushed up or down and how strongly.

**Expected Behavior / Usage:**

Consider the period-over-period price changes. Within the window ending at position `i`, sum the magnitudes of all upward changes and, separately, of all downward changes. The average gain and average loss are each of these sums divided by the number of positions seen so far, capped at `timeFrame` (so early positions divide by `i+1`). The relative strength is `averageGain / averageLoss`, and the index is `100 - 100 / (1 + relativeStrength)`. Two boundary rules apply: the value at position `0` is always `0`, and whenever the window contains no downward change (the average loss is zero) the value is exactly `100`. Each value is rendered rounded half-up to four fractional digits.

**Test Cases:** `rcb_tests/public_test_cases/feature4_rsi_momentum.json`

```json
{
    "description": "Compute the relative strength index of a close-price series for a given window length, using simple averages of upward and downward price changes. The output is the indicator curve: one value per position, in order, each rounded half-up to four decimal places. The first position is always zero. For each later position, the average gain and average loss are the sums of upward (respectively downward) changes within the window divided by the number of positions seen so far (capped at the window length); the value is 100 minus 100/(1+averageGain/averageLoss). When there is no downward change in the window (average loss is zero), the value is exactly 100.",
    "cases": [
        {
            "input": {"indicator": "rsi", "timeFrame": 14, "series": [50.45, 50.30, 50.20, 50.15, 50.05, 50.06, 50.10, 50.08, 50.03, 50.07, 50.01, 50.14, 50.22, 50.43, 50.50, 50.56, 50.52, 50.70, 50.55, 50.62, 50.90, 50.82, 50.86, 51.20, 51.30, 51.10]},
            "expected_output": "0.0000\n0.0000\n0.0000\n0.0000\n0.0000\n2.4390\n11.1111\n10.6383\n9.6154\n16.0714\n14.5161\n29.3333\n36.1446\n49.0385\n52.2523\n62.7451\n66.6667\n75.2294\n71.9298\n73.3333\n77.7778\n74.6667\n77.8523\n81.5642\n85.2459\n75.2632"
        }
    ]
}
```

---

## Deliverables

1. **The Core System:** A cleanly structured codebase implementing the four indicators above. Its physical structure (single-file vs. multi-file repository) MUST strictly align with the "Scale-Driven Code Organization" constraint. The core indicator logic must be decoupled from standard I/O (stdin/stdout) and JSON parsing, and indicators should compose over a shared price-series/source abstraction.

2. **The Execution/Test Adapter:** A runnable program (CLI script or entry point) that acts as a client to your core system — logically (and ideally physically) separated from the core domain. It reads a single JSON request from stdin (`indicator`, `timeFrame`, `series`), invokes the matching indicator over the series, and prints the resulting curve to stdout: one fixed-precision decimal value per series position, in order, each followed by a newline, rounded half-up to four fractional digits. An unrecognised `indicator` yields the neutral two-line error described above; a mathematically undefined value renders as `[a special string literal for undefined values]`.

3. **Automated test harness**. The cases embedded in this PRD live under `rcb_tests/public_test_cases/`. A single entry point `bash rcb_tests/test.sh` reads every `*.json` case file from a case directory and runs the full suite; it accepts `--cases-dir <subdir>` to point at a directory of case files (default `test_cases`). For each case it writes one file to `rcb_tests/stdout/<cases-dir>/{filename.stem}@{case_index.zfill(3)}.txt`. Output is namespaced by `<cases-dir>` so running different case directories never overwrites each other. Each `.txt` file contains **only** the raw stdout from the program under test (no PASS/FAIL summaries or metadata) so it can be compared directly against `expected_output`.


---
**Implementation notes:**
- follow the exponential smoothing logic used in the EMA module
- use the weighted standard approach found in the WMA implementation
